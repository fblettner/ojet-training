// injector:preactDebugImport
// endinjector
import './components/app';