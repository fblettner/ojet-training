export = {
  "apps-config": {
    "sampleString": "The strings file can be used to manage translatable resources"
  }
};