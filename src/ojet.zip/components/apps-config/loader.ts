export { AppsConfig } from "./apps-config";
