export = {
  "apps-header": {
    "sampleString": "The strings file can be used to manage translatable resources"
  }
};