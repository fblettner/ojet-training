declare const _default: {
    "apps-footer": {
        sampleString: string;
    };
};
export = _default;
