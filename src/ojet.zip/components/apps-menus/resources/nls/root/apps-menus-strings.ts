export = {
  "apps-menus": {
    "sampleString": "The strings file can be used to manage translatable resources"
  }
};